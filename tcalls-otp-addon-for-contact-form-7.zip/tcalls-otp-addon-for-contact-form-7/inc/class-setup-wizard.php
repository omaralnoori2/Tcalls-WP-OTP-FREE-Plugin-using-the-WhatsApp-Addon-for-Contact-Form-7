<?php
defined( 'ABSPATH' ) || exit;
/**
 * Setup Wizard Class
 * @since 2.9.3
 * @author Foysal
 */
if ( ! class_exists( 'UACF7_Setup_Wizard' ) ) {
	class UACF7_Setup_Wizard {

		private static $instance = null;
		private static $current_step = null;

		private $addons = [];

		/**
		 * Singleton instance
		 * @since 1.0.0
		 */
		public static function instance() {
			if ( self::$instance == null ) {
				self::$instance = new self;
			}

			return self::$instance;
		}

		public function __construct() {
			add_action( 'admin_menu', [ $this, 'uacf7_wizard_menu' ], 100 );
			add_filter( 'uacf7_settings_options', [ $this, 'uacf7_settings_options_wizard' ], 100 );
			add_action( 'admin_init', [ $this, 'tf_activation_redirect' ] );
			add_action( 'wp_ajax_uacf7_onclick_ajax_activate_plugin', [ $this, 'uacf7_onclick_ajax_activate_plugin' ] );
			add_action( 'wp_ajax_uacf7_form_generator_ai_quick_start', [ $this, 'uacf7_form_generator_ai_quick_start' ] );
			add_action( 'wp_ajax_uacf7_form_quick_create_form', [ $this, 'uacf7_form_quick_create_form' ] );
			add_action( 'in_admin_header', [ $this, 'remove_notice' ], 1000 );
			if ( ! is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ) {
				add_action( 'wp_ajax_contact_form_7_ajax_install_plugin', 'wp_ajax_install_plugin' );
			}
			self::$current_step = isset( $_GET['step'] ) ? sanitize_key( $_GET['step'] ) : 'welcome';
		}

		public function uacf7_settings_options_wizard( $option ) {
			$this->addons = $option;
			return $option;
		}

		/**
		 * Add wizard submenu
		 */
		public function uacf7_wizard_menu() {
			if ( current_user_can( 'manage_options' ) ) {
				add_submenu_page(
					'uacf7-setup-wizard',
					esc_html__( 'UACF7 Setup Wizard', 'tcalls-otp-addon-for-contact-form-7' ),
					esc_html__( 'UACF7 Setup Wizard', 'tcalls-otp-addon-for-contact-form-7' ),
					'manage_options',
					'uacf7-setup-wizard',
					[ $this, 'uacf7_wizard_page' ],
					99
				);
			}
		}

		/**
		 * Remove all notice in setup wizard page
		 */
		public function remove_notice() {
			if ( isset( $_GET['page'] ) && $_GET['page'] == 'uacf7-setup-wizard' ) {
				remove_all_actions( 'admin_notices' );
				remove_all_actions( 'all_admin_notices' );
			}
		}


		/**
		 * One Click CF7 Plugin Install
		 */
		public function uacf7_onclick_ajax_activate_plugin() {

			check_ajax_referer( 'updates', '_ajax_nonce' );
			// Check user capabilities
			if ( ! current_user_can( 'install_plugins' ) ) {
				wp_send_json_error( 'Permission denied' );
			}

			// activate the plugin
			$plugin_slug = sanitize_text_field( wp_unslash( $_POST['slug'] ) );
			$file_name = sanitize_text_field( wp_unslash( $_POST['file_name'] ) );
			$result = activate_plugin( $plugin_slug . '/' . $file_name . '.php' );

			if ( is_wp_error( $result ) ) {
				wp_send_json_error( 'Error: ' . $result->get_error_message() );
			} else {
				wp_send_json_success( 'Plugin installed and activated successfully!' );
			}
			wp_die();
		}

		/**
		 * One Click Form Generator AI Plugin Install
		 */
		public function uacf7_form_generator_ai_quick_start() {

			check_ajax_referer( 'updates', '_ajax_nonce' );
			// Check user capabilities
			if ( ! current_user_can( 'install_plugins' ) ) {
				wp_send_json_error( 'Permission denied' );
			}

			$vaue = '';
			$uacf7_default[0] = 'form';
			$uacf7_default[1] = $_POST['searchValue'];


			if ( count( $uacf7_default ) > 0 && $uacf7_default[0] == 'form' ) {

				$value = require_once UACF7_PATH . 'addons/form-generator-ai/templates/uacf7-forms.php';
			}
			$data = [ 
				'status' => 'success',
				'value' => $value,
			];
			echo wp_send_json( $data );
			die();
		}


		/**
		 * Create New Contact Form
		 */
		public function uacf7_form_quick_create_form() {
			check_ajax_referer( 'updates', '_ajax_nonce' );
			// Check user capabilities
			if ( ! current_user_can( 'install_plugins' ) ) {
				wp_send_json_error( 'Permission denied' );
			}

			$vaue = '';
			$form_name = $_POST['form_name'];
			$form_value = str_replace( "\\", "", $_POST['form_value'] );
			$message = '';
			$status = 'success';

			if ( class_exists( 'WPCF7' ) ) {

				// Create a new form
				$contact_form = WPCF7_ContactForm::get_template(
					array(
						'title' => $form_name,
					)
				);
				$properties = $contact_form->get_properties();
				$properties['form'] = $form_value;
				$contact_form->set_properties( $properties );
				// $contact_form->save();


				// Save the form
				if ( $contact_form ) {
					$contact_form->save();
				} else {
					$message = 'Error creating the form.';
					$status = 'error';
				}


			}
			$data = [ 
				'status' => $status,
				'form_id' => $contact_form->id(),
				'edit_url' => admin_url( 'admin.php?page=wpcf7&post=' . $contact_form->id() . '&action=edit' ),
				'message' => $message,
			];
			echo wp_send_json( $data );
			die();
		}

		/**
		 * Setup wizard page
		 */
		public function uacf7_wizard_page() {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
			$plugin_to_check = 'contact-form-7/wp-contact-form-7.php';

			if ( file_exists( WP_PLUGIN_DIR . '/' . $plugin_to_check ) ) {
				$uacf7_plugin_status = ( is_plugin_active( $plugin_to_check ) ) ? 'activate' : 'not_active';
			} else {
				$uacf7_plugin_status = 'not_installed';
			}

			if ( $uacf7_plugin_status == 'activate' ) {
				$data_current_step = 2;
				$data_next_step = 3;
			} else {
				$data_current_step = 1;
				$data_next_step = 2;
			}

			$option_form = [ 
				[ "value" => "multistep", "label" => "Multistep" ],
				apply_filters( 'uacf7_booking_ai_form_dropdown', [ "value" => "booking", "label" => "Booking (Pro)" ] ),
				[ "value" => "conditional", "label" => "Conditional" ],
				[ "value" => "subscription", "label" => "Subscription" ],
				apply_filters( 'uacf7_repeater_ai_form_dropdown', [ "value" => "repeater", "label" => "Repeater (Pro)" ] ),
				apply_filters( 'uacf7_blog_submission_ai_form_dropdown', [ "value" => "blog", "label" => "Blog Submission (Pro)" ] ),
				[ "value" => "feedback", "label" => "Feedback" ],
				[ "value" => "application", "label" => "Application" ],
				[ "value" => "inquiry", "label" => "Inquiry" ],
				[ "value" => "survey", "label" => "Survey" ],
				[ "value" => "address", "label" => "Address" ],
				[ "value" => "event", "label" => "Event Registration" ],
				[ "value" => "newsletter", "label" => "Newsletter" ],
				[ "value" => "donation", "label" => "Donation" ],
				[ "value" => "product-review", "label" => "Product Review" ],
				apply_filters( 'uacf7_service_booking_form_dropdown', [ "value" => "service-booking", "label" => "Service Booking (Pro)" ] ),
				apply_filters( 'uacf7_appointment_form_dropdown', [ "value" => "appointment-form", "label" => "Appointment (Pro)" ] ),
				apply_filters( 'uacf7_conversational_appointment_form_dropdown', [ "value" => "conversational-appointment-form", "label" => "Conversational Appointment Booking  (Pro)" ] ),
				apply_filters( 'uacf7_conversational_interview_form_dropdown', [ "value" => "conversational-interview-form", "label" => "Conversational Interview Process (Pro)" ] ),
				[ "value" => "rating", "label" => "Rating" ],
			];

			?>
			<div class="uacf7-setup-wizard">
				<div class="uacf7-wizard-header">
					<div class="uacf7-step-items-container">
						<div class="uacf7-single-step-item step-first  active" data-step="1">
							<span class="step-item-dots ">
								<?php if ( $uacf7_plugin_status == 'activate' ) {
									?>
									<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path fill-rule="evenodd" clip-rule="evenodd"
											d="M17.0965 7.39016L9.9365 14.3002L8.0365 12.2702C7.6865 11.9402 7.1365 11.9202 6.7365 12.2002C6.3465 12.4902 6.2365 13.0002 6.4765 13.4102L8.7265 17.0702C8.9465 17.4102 9.3265 17.6202 9.7565 17.6202C10.1665 17.6202 10.5565 17.4102 10.7765 17.0702C11.1365 16.6002 18.0065 8.41016 18.0065 8.41016C18.9065 7.49016 17.8165 6.68016 17.0965 7.38016V7.39016Z"
											fill="#7F56D9" />
									</svg>
								<?php
								} else {
									?>
									<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
										<rect width="24" height="24" rx="12" fill="#F9F5FF"/>
										<circle cx="12" cy="12" r="4" fill="#7F56D9" />
									</svg>
									<?php

								} ?>

							</span>
							<span class="step-item-title"><?php echo esc_html( 'Installation' ) ?></span>
						</div>
						<div class="uacf7-single-step-item <?php if ( $uacf7_plugin_status == 'activate' ) {
							echo esc_attr( 'active' );
						} ?>"
							data-step="2">
							<span class="step-item-dots">
								<?php if ( $uacf7_plugin_status == 'activate' ) {
									?>
									<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
										<rect width="24" height="24" rx="12" fill="#F9F5FF" />
										<circle cx="12" cy="12" r="4" fill="#7F56D9" />
									</svg>
								<?php
								} else {
									?>
									<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
										<circle cx="12" cy="12" r="4" fill="#EAECF0" />
									</svg>
									<?php

								} ?>

							</span>
							<span class="step-item-title"><?php echo esc_html( 'Activate addon' ) ?> </span>
						</div>
						<div class="uacf7-single-step-item" data-step="3">
							<span class="step-item-dots">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<circle cx="12" cy="12" r="4" fill="#EAECF0" />
								</svg>
							</span>
							<span class="step-item-title"><?php echo esc_html( 'Form type' ) ?></span>
						</div>
						<div class="uacf7-single-step-item step-last" data-step="4">
							<span class="step-item-dots">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<circle cx="12" cy="12" r="4" fill="#EAECF0" />
								</svg>
							</span>
							<span class="step-item-title"><?php echo esc_html( 'Generate & Preview' ) ?></span>
						</div>
					</div>
				</div>
				<div class="uacf7-step-content-container">
					<div class="uacf7-single-step-content installation <?php if ( $uacf7_plugin_status != 'activate' ) {
						echo esc_attr( 'active' );
					} ?>"
						data-step="1">
						<div class="uacf7-single-step-content-wrap">
							<span class="uacf7-wizard-logo">
								<img style="height:100px; width:100px;" src="<?php echo UACF7_URL; ?>assets/img/tcalls-icon.png" alt="logo">
							</span>

							<div class="uacf7-single-step-content-inner">
								<h1><?php echo _e( 'Welcome to Tcalls OTP Addon for Contact Form 7', 'tcalls-otp-addon-for-contact-form-7' ) ?></h1>

								<p><?php echo _e( "The easiest and best Contact Form 7 Addons Plugin for WordPress. With 28+ essential features, this all-in-one plugin includes nearly all the basic to advanced options for your site's contact form.", 'tcalls-otp-addon-for-contact-form-7' ) ?>
								</p>

								<div class="uacf7-step-plugin-required">
									<p><?php echo esc_html( 'To continue, the plugin requires Contact Form 7' ) ?> <br> to be
										<?php if ( $uacf7_plugin_status == 'not_active' ) {
											echo '<strong>' . esc_html( "installed" ) . '</strong> ' . esc_html( " & activated.", ) . ' ';
										} else {
											echo esc_html( "installed & activated." );
										} ?>
									</p>
									<button
										class="required-plugin-button uacf7-setup-widzard-btn <?php if ( $uacf7_plugin_status == 'activate' ) {
											echo 'disabled';
										} ?>"
										<?php if ( $uacf7_plugin_status == 'activate' ) {
											echo 'disabled ="disabled"';
										} ?>
										data-plugin-status="<?php echo esc_attr( $uacf7_plugin_status ) ?>">

										<?php
										if ( 'activate' == $uacf7_plugin_status ) {
											echo esc_html( 'Activated' );
										} else if ( 'not_installed' == $uacf7_plugin_status ) {
											echo esc_html( 'Install & Activate now' );
										} else {
											echo esc_html( 'Activate now' );
										}
										?>

									</button>
								</div>
							</div>
						</div>
					</div>
					<div class="uacf7-single-step-content chooes-addon <?php if ( $uacf7_plugin_status == 'activate' ) {
						echo esc_attr( 'active' );
					} ?> "
						data-step="2">
						<div class="uacf7-single-step-content-wrap">
							<h2><?php echo _e( 'Activate your addon', 'tcalls-otp-addon-for-contact-form-7' ) ?></h2>
							<p><?php echo _e( 'Please activate the addon you need. This helps avoid loading unnecessary assets (JS, CSS).', 'tcalls-otp-addon-for-contact-form-7' ) ?>.
							</p>
							<form method="post" action="" class="tf-option-form tf-ajax-save" enctype="multipart/form-data">

								<input type="hidden" name="uacf7_current_page" value="waotpcf7_addon_page">
								<div class="uacf7-addon-setting-content">
									<?php
									$data = get_option( 'uacf7_settings', true );

									$fields = [];
									foreach ( $this->addons as $section_key => $section ) :
										if ( $section_key == 'general_addons' || $section_key == 'extra_fields_addons' || $section_key == 'wooCommerce_integration' ) :

											$fields = array_merge( $fields, $section['fields'] );

										endif;
									endforeach;

									//  Short as Alphabetically
									usort( $fields, array( $this, 'uacf7_setup_wizard_sorting' ) );

									foreach ( $fields as $field_key => $field ) :
										$id = 'uacf7_settings' . '[' . $field['id'] . ']';
										?>
										<div class="uacf7-single-addon-setting uacf7-fields-<?php echo esc_attr( $field['id'] ) ?>"
											data-parent="<?php echo esc_attr( $section_key ) ?>"
											data-filter="<?php echo esc_html( strtolower( $field['label'] ) ) ?>">
											<?php
											$label_class = '';
											if ( isset( $field['is_pro'] ) ) {
												$label_class .= $field['is_pro'] == true ? 'tf-field-disable tf-field-pro' : '';
												$badge = '<span class="addon-status pro">' . esc_html( 'Pro' ) . '</span>';
											} else {
												$badge = '<span class="addon-status">' . esc_html( 'Free' ) . '</span>';
											}
											$child = isset( $field['child_field'] ) ? $field['child_field'] : '';
											$is_pro = isset( $field['is_pro'] ) ? 'pro' : '';
											$default = $field['default'] == true ? 'checked' : '';
											$default = isset( $data[ $field['id'] ] ) && $data[ $field['id'] ] == 1 ? 'checked' : $default;
											$value = isset( $data[ $field['id'] ] ) ? $data[ $field['id'] ] : 0;
											$demo_link = isset( $field['demo_link'] ) ? $field['demo_link'] : '#';
											$documentation_link = isset( $field['documentation_link'] ) ? $field['documentation_link'] : '#';

											// echo $default; 
											?>
											<div class="uacf7-single-addons-wrap">
												<?php echo $badge; ?>
												<h2 class="uacf7-single-addon-title"><?php echo esc_html( $field['label'] ) ?></h2>
												<div class="uacf7-addon-toggle-wrap">
													<input type="checkbox" id="<?php echo esc_attr( $field['id'] ) ?>"
														data-child="<?php echo esc_attr( $child ) ?>"
														data-is-pro="<?php echo esc_attr( $is_pro ) ?>" <?php echo esc_attr( $default ) ?>
														value="<?php echo esc_html( $value ); ?>" class="uacf7-addon-input-field"
														name="<?php echo esc_attr( $id ) ?>" id="uacf7_enable_redirection">

													<label class="uacf7-addon-toggle-inner <?php echo esc_attr( $label_class ) ?> "
														for="<?php echo esc_attr( $field['id'] ) ?>">
														<span class="uacf7-addon-toggle-track"><svg width="16" height="17"
																viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
																<rect y="0.5" width="16" height="16" rx="8" fill="#79757F" />
															</svg>
														</span>
													</label>
												</div>
											</div>
										</div>

									<?php
									endforeach;
									?>


								</div>
								<?php wp_nonce_field( 'tf_option_nonce_action', 'tf_option_nonce' ); ?>
							</form>
						</div>
					</div>
					<div class="uacf7-single-step-content form-type" data-step="3">
						<div class="uacf7-single-step-content-wrap">
							<div class="uacf7-single-step-content-inner">
								<div class="uacf7-form-generate">
									<h3>
										<?php echo sprintf(
											__( 'AI Form Generator<span>Our AI Form Generator creates a basic form for you, based on your selected category from the dropdown menu below. You can then customize this form to suit your specific requirements.</span>', 'tcalls-otp-addon-for-contact-form-7' ) ); ?>
									</h3>
									<label for="uacf7-select-form">
										<select name="uacf7-select-form" class="tf-select2" id="uacf7-select-form">
											<option value=""><?php echo esc_html( 'Choose Form type', 'tcalls-otp-addon-for-contact-form-7' ) ?>
											</option>
											<?php
											foreach ( $option_form as $key => $form ) :
												?>
												<option value="<?php echo esc_attr( $form['value'] ); ?>">
													<?php echo esc_attr( $form['label'] ) ?></option>
											<?php endforeach; ?>
										</select>
									</label>
								</div>
								<button class="uacf7-generate-form uacf7-setup-widzard-btn" style="display:none;"
									data-current-step="1"
									data-next-step="2"><?php echo esc_html( 'Generate with AI', 'tcalls-otp-addon-for-contact-form-7' ) ?>

									<svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
										<g clip-path="url(#clip0_143_4913)">
											<path
												d="M9.58008 3.39453L11.25 2.75L11.8652 1.10938C11.8945 0.962891 12.041 0.875 12.1875 0.875C12.3047 0.875 12.4512 0.962891 12.4805 1.10938L13.125 2.75L14.7656 3.39453C14.9121 3.42383 15 3.57031 15 3.6875C15 3.83398 14.9121 3.98047 14.7656 4.00977L13.125 4.625L12.4805 6.29492C12.4512 6.41211 12.3047 6.5 12.1875 6.5C12.041 6.5 11.8945 6.41211 11.8652 6.29492L11.25 4.625L9.58008 4.00977C9.43359 3.98047 9.375 3.83398 9.375 3.6875C9.375 3.57031 9.43359 3.42383 9.58008 3.39453ZM7.5293 6.38281L10.8691 7.90625C11.0449 7.99414 11.1621 8.16992 11.1621 8.3457C11.1621 8.52148 11.0449 8.69727 10.8691 8.78516L7.5293 10.3086L6.00586 13.6484C5.91797 13.8242 5.74219 13.9414 5.56641 13.9414C5.39062 13.9414 5.21484 13.8242 5.15625 13.6484L3.60352 10.3086L0.263672 8.78516C0.0878906 8.69727 0 8.52148 0 8.3457C0 8.16992 0.0878906 7.99414 0.263672 7.90625L3.60352 6.38281L5.15625 3.04297C5.21484 2.86719 5.39062 2.75 5.56641 2.75C5.74219 2.75 5.91797 2.86719 6.00586 3.04297L7.5293 6.38281ZM11.8652 10.4844C11.8945 10.3379 12.041 10.25 12.1875 10.25C12.3047 10.25 12.4512 10.3379 12.4805 10.4844L13.125 12.125L14.7656 12.7695C14.9121 12.7988 15 12.9453 15 13.0625C15 13.209 14.9121 13.3555 14.7656 13.3848L13.125 14L12.4805 15.6699C12.4512 15.7871 12.3047 15.875 12.1875 15.875C12.041 15.875 11.8945 15.7871 11.8652 15.6699L11.25 14L9.58008 13.3848C9.43359 13.3555 9.375 13.209 9.375 13.0625C9.375 12.9453 9.43359 12.7988 9.58008 12.7695L11.25 12.125L11.8652 10.4844Z"
												fill="white" />
										</g>
										<defs>
											<clipPath id="clip0_143_4913">
												<rect width="15" height="16" fill="white" />
											</clipPath>
										</defs>
									</svg>
								</button>
							</div>
							<div class="uacf7-single-step-content-inner">
								<img src="<?php echo UACF7_URL ?>assets/admin/images/quick-setup.svg" alt="quick-setup">

								<div class="uacf7-generated-template" style="display:none">
									<!-- <textarea name="uacf7-generated-form" id="uacf7_ai_code_content" cols="30" rows="10"></textarea> -->
									<div class="uacf7-ai-codeblock">
										<textarea name="uacf7-generated-form" id="uacf7_ai_code_content"></textarea>
									</div>
									<button
										class="uacf7-create-form uacf7-setup-widzard-btn "><?php echo esc_html( 'Create your form', 'tcalls-otp-addon-for-contact-form-7' ) ?></button>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="uacf7-wizard-footer">
					<div class="uacf7-wizard-footer-inner">
						<div class="uacf7-wizard-footer-left">
							<a href="<?php echo esc_url( admin_url() ) ?>"
								class="uacf7-wizard-footer-left-link uacf7-back-dashboard"><?php echo esc_html( 'Back to Dashboard', 'tcalls-otp-addon-for-contact-form-7' ) ?></a>
						</div>

						<div class="uacf7-wizard-footer-right">

							<a href="<?php echo esc_url( admin_url() ) ?>admin.php?page=uacf7_settings#tab=mailchimp" class="wizard_uacf7_btn_back_addon" style="display: none">
								<?php echo esc_html( 'Go to settings', 'tcalls-otp-addon-for-contact-form-7' ) ?>
							</a>

							<button
								class="uacf7-wizard-footer-right-button uacf7-next uacf7-setup-widzard-btn <?php if ( $uacf7_plugin_status != 'activate' ) {
									echo 'disabled';
								} ?>"
								<?php if ( $uacf7_plugin_status != 'activate' ) {
									echo 'disabled ="disabled"';
								} ?>
								data-current-step="<?php echo esc_attr( $data_current_step ) ?>"
								data-next-step="<?php echo esc_attr( $data_next_step ) ?>"> Next

								<svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M12.3337 4.99951L1.66699 4.99951" stroke="white" stroke-width="1.5"
										stroke-linecap="round" stroke-linejoin="round" />
									<path
										d="M9.00051 8.33317C9.00051 8.33317 12.3338 5.87821 12.3338 4.99981C12.3338 4.12141 9.00049 1.6665 9.00049 1.6665"
										stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
								</svg>
							</button>
						</div>
					</div>
				</div>
			</div>
			<?php
		}

		// Custom comparison function based on 'label' value
		public function uacf7_setup_wizard_sorting( $a, $b ) {
			$labelA = $a['label'][0];
			$labelB = $b['label'][0];
			return strcmp( $labelA, $labelB );
		}

		/**
		 * redirect to set up wizard when active plugin
		 */
		public function tf_activation_redirect( $screen ) {
			// if ( ! get_option( 'uacf7_setup_wizard' ) ) {
			// 	update_option( 'uacf7_setup_wizard', 'active' );
			// 	if ( is_network_admin() ) {
			// 		$url = network_admin_url( 'admin.php?page=uacf7-setup-wizard' );
			// 	} else {
			// 		$url = admin_url( 'admin.php?page=uacf7-setup-wizard' );
			// 	}

			// 	wp_redirect( $url );
			// 	exit;
			// }
		}


	}
}

UACF7_Setup_Wizard::instance();