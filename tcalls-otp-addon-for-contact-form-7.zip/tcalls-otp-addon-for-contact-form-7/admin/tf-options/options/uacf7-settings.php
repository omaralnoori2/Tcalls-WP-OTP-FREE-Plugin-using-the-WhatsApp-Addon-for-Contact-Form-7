<?php
// don't load directly
defined('ABSPATH') || exit;

if (file_exists(UACF7_PATH . 'admin/tf-options/options/tf-menu-icon.php')) {

	$menu_icon = UACF7_URL . 'assets/admin/images/icon.png';
} else {
	$menu_icon = 'dashicons-palmtree';
}

UACF7_Settings::option(
	'uacf7_settings',
	array(
		'title' => __('Tcalls OTP Addon', 'tcalls-otp-addon-for-contact-form-7'),
		'icon' => $menu_icon,
		'position' => 30.01,
		'sections' =>
			apply_filters(
				'uacf7_settings_options',
				array(
					'addons_settings' => array(
						'title' => __('Addons Settings', 'tcalls-otp-addon-for-contact-form-7'),
						'icon' => 'fa fa-cog',
						'fields' => array(
						),
					),
					
					'extra_fields_addons' => array(
						'title' => __('Extra Fields Addons', 'tcalls-otp-addon-for-contact-form-7'),
						'parent' => 'addons_settings',
						'icon' => 'fa fa-cog',
						'fields' => array(
							'uacf7_enable_wa_otp_field' => array(
								'id' => 'uacf7_enable_wa_otp_field',
								// 'child_field' => 'uacf7_enable_wa_otp_pro',
								'type' => 'switch',
								'label' => __('Whatsapp OTP', 'tcalls-otp-addon-for-contact-form-7'),
								'label_on' => __('Yes', 'tcalls-otp-addon-for-contact-form-7'),
								'label_off' => __('No', 'tcalls-otp-addon-for-contact-form-7'),
								'image_url' => UACF7_URL . 'assets/admin/images/addons/tcalls.png',
								'default' => false,
								'subtitle' => __('This feature is highly effective in ', 'tcalls-otp-addon-for-contact-form-7'),
								'demo_link' => 'https://tcalls.com/',
								'documentation_link' => 'https://tcalls.com/opt-plugin-documentation/',
								'field_width' => 33,
							),
						),
					),
				),
			)
	)
);
