<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UACF7_SPAM_PROTECTION {

	public function __construct() {

		add_action( 'wpcf7_init', array( $this, 'uacf7_wa_otp_add_shortcodes' ), 5, 10 );
		add_action( 'admin_init', array( $this, 'uacf7_wa_otp_tag_generator' ) );
		// add_filter( 'uacf7_post_meta_options', array( $this, 'uacf7_post_meta_options_wa_otp' ), 34, 2 );
		add_action( 'wp_enqueue_scripts', array( $this, 'uacf7_wa_otp_scripts' ), 5, 10 );

		// add_filter( 'wpcf7_load_js', '__return_false' );
	}

	public function uacf7_wa_otp_scripts() {
		$option = uacf7_settings();
		$wa_otp_pro = ( isset( $option['uacf7_enable_wa_otp_pro'] ) && $option['uacf7_enable_wa_otp_pro'] == '1' ) ? true : false;
		wp_register_script( 'uacf7-wa-otp-otp', UACF7_URL . 'addons/wa-otp/assets/js/wa-otp-otp.js', [ 'jquery' ], WPCF7_VERSION, true );
		wp_register_script( 'uacf7-wa-otp-image', UACF7_URL . 'addons/wa-otp/assets/js/wa-otp-image.js', [ 'jquery' ], WPCF7_VERSION, true );
		wp_enqueue_style( 'uacf7-wa-otp-css', UACF7_URL . 'addons/wa-otp/assets/css/wa-otp-style.css', [], WPCF7_VERSION, 'all' );

		// Localize the script to pass PHP data to JavaScript
		wp_localize_script(
			'uacf7-wa-otp-otp', // The handle of the script to localize
			'uacf7_wa_otp_settings',  // Name of the JavaScript object
			[ 
				'enable_wa_otp_pro' => $wa_otp_pro, // Data to pass
				'otpRequiredMessage' => __( 'OTP field is required. Please enter the OTP.', 'tcalls-otp-addon-for-contact-form-7' ),
				'otpValidatedMessage' => __( 'OTP validated successfully.', 'tcalls-otp-addon-for-contact-form-7' ),
				'otpValidationFailed' => __( 'OTP validation failed. Please try again.', 'tcalls-otp-addon-for-contact-form-7' ),

                'ajax_url' => admin_url( 'admin-ajax.php' ),
			]
		);
		// Localize the script to pass PHP data to JavaScript
		// wp_localize_script(
		// 	'uacf7-wa-otp-image', 'uacf7_wa_otp_settings', [ 
		// 		'enable_wa_otp_pro' => $wa_otp_pro, // Data to pass
		// 		'captchaRequiredMessage' => __( 'CAPTCHA field is required. Please enter the answer.', 'tcalls-otp-addon-for-contact-form-7' ),
		// 		'captchaSuccessMessage' => __( 'CAPTCHA validated successfully.', 'tcalls-otp-addon-for-contact-form-7' ),
		// 		'captchaFailedMessage' => __( 'CAPTCHA validation failed. Please try again.', 'tcalls-otp-addon-for-contact-form-7' ),
		// 	]
		// );

	}


	public function uacf7_post_meta_options_wa_otp( $value, $post_id ) {
		$wa_otp = apply_filters( 'uacf7_post_meta_options_wa_otp_pro', $data = array(
			'title' => __( 'Wa OTP', 'tcalls-otp-addon-for-contact-form-7' ),
			'icon' => 'fa-brands fa-square-whatsapp',
			'checked_field' => 'uacf7_wa_otp_enable',

			'fields' => array(
				// 'uacf7_wa_otp_heading' => array(
				// 	'id' => 'uacf7_wa_otp_heading',
				// 	'type' => 'heading',
				// 	'label' => __( 'Wa OTP Settings', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'subtitle' => __( 'This feature will help you to .', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'content' => sprintf(
				// 		// Translators: %1$s is replaced with the link to documentation.
				// 		esc_html__( 'Add Wa OTP for your contact form 7 forms. %s .', 'tcalls-otp-addon-for-contact-form-7' ),
				// 		'<a href="https://tcalls.com/" target="_blank">See Demo</a>',

				// 	),
				// ),

				// array(
				// 	'id' => 'wa-otp-docs',
				// 	'type' => 'notice',
				// 	'style' => 'success',
				// 	'content' => sprintf(
				// 		// Translators: %1$s is replaced with the link to documentation. 
				// 		esc_html__( 'Not sure how to set this? Check our step-by-step documentation on  %s .', 'tcalls-otp-addon-for-contact-form-7' ),
				// 		'<a href="https://tcalls.com/" target="_blank">Tcalls</a>',
				// 	),
				// ),

				// 'uacf7_wa_otp_enable' => array(
				// 	'id' => 'uacf7_wa_otp_enable',
				// 	'type' => 'switch',
				// 	'label' => __( 'Enable Wa OTP', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'label_on' => __( 'Yes', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'label_off' => __( 'No', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'default' => false
				// ),
				// 'uacf7_wa_otp_type' => array(
				// 	'id' => 'uacf7_wa_otp_type',
				// 	'type' => 'select',
				// 	'label' => __( 'Protection Type', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'options' => array(
				// 		'otp_recognation' => 'Arithmetic Recognition',
				// 		'image_recognation' => 'Image Recognition',
				// 	),
				// 	'default' => 'otp_recognation'
				// ),
				// 'uacf7_minimum_time_limit' => array(
				// 	'id' => 'uacf7_minimum_time_limit',
				// 	'type' => 'number',
				// 	'label' => __( 'Each Submission Difference', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'subtitle' => __( 'To prevent spamming bots, you can set a time limit to restrict too frequent submissions. Please specify the time limit in seconds. Default: 5 seconds', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'placeholder' => __( '5', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'default' => 5,
				// 	'is_pro' => true
				// ),
				// 'uacf7_word_filter' => array(
				// 	'id' => 'uacf7_word_filter',
				// 	'type' => 'textarea',
				// 	'label' => __('Word Filtering', 'tcalls-otp-addon-for-contact-form-7'),
				// 	'subtitle' => __('Enlist the words you want to avoid from Spammer, Separate the words using a Comma. If that word/s found in the message it will skip to the email (email will not send to mail)', 'tcalls-otp-addon-for-contact-form-7'),
				// 	'placeholder' => __('E.g. evil, earning money, scam', 'tcalls-otp-addon-for-contact-form-7'),
				// 	'is_pro' => true
				// ),
				// 'uacf7_ip_block' => array(
				// 	'id' => 'uacf7_ip_block',
				// 	'type' => 'textarea',
				// 	'label' => __( 'IP Block', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'subtitle' => __( 'Enlist the IP you want to Ban / Block, Separate the IPs using a Comma', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'placeholder' => __( 'E.g. 192.158.1.38,192.158.1.39,192.158.1.40', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'is_pro' => true
				// ),
				// 'uacf7_blocked_countries' => array(
				// 	'id' => 'uacf7_blocked_countries',
				// 	'type' => 'textarea',
				// 	'label' => __( 'Country Block', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'subtitle' => sprintf(
				// 		// Translators: %1$s is replaced with the link to documentation.
				// 		esc_html__( 'Enlist the Country or Countries that you want to Ban / Block. Separate the Countries %s using a Comma', 'tcalls-otp-addon-for-contact-form-7' ),
				// 		'<a href="https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2#Officially_assigned_code_elements" target="_blank">' . __( 'iso2 name', 'tcalls-otp-addon-for-contact-form-7' ) . '</a>'
				// 	),
				// 	'placeholder' => __( 'E.g. us,ca,uk', 'tcalls-otp-addon-for-contact-form-7' ),
				// 	'is_pro' => true
				// ),

			)

		), $post_id );

		$value['wa_otp'] = $wa_otp;
		return $value;
	}


	public function uacf7_wa_otp_tag_generator() {
		wpcf7_add_tag_generator(
			'uacf7_wa_otp',
			__( 'Wa OTP', 'tcalls-otp-addon-for-contact-form-7' ),
			'uacf7-tg-pane-wa-otp',
			array( $this, 'tg_pane_wa_otp' )
		);
	}


	public static function tg_pane_wa_otp( $contact_form, $args = '' ) {
		$args = wp_parse_args( $args, array() );
		$uacf7_field_type = 'uacf7_wa_otp';
		?>
		<div class="control-box">
			<fieldset>
				<table class="form-table">
					<tbody>
						<div class="uacf7-doc-notice">
							<?php echo sprintf(
								// Translators: %1$s is replaced with the link to documentation. 
								esc_html__( 'Not sure how to set this? Check our step by step  %1s.', 'tcalls-otp-addon-for-contact-form-7' ),
								'<a href="https://tcalls.com/opt-plugin-documentation/" target="_blank">documentation</a>'
							); ?>
						</div>
						<tr>
							<th scope="row"><label
									for="<?php echo esc_attr( $args['content'] . '-name' ); ?>"><?php echo esc_html( __( 'Name', 'tcalls-otp-addon-for-contact-form-7' ) ); ?></label>
							</th>
							<td><input type="text" name="name" class="tg-name oneline"
									id="<?php echo esc_attr( $args['content'] . '-name' ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><label
									for="tag-generator-panel-text-class"><?php echo esc_html__( 'Class attribute', 'tcalls-otp-addon-for-contact-form-7' ); ?></label>
							</th>
							<td><input type="text" name="class" class="classvalue oneline option"
									id="tag-generator-panel-text-class"></td>
						</tr>
					</tbody>
				</table>
			</fieldset>
		</div>
		<div class="insert-box">
			<input type="text" name="<?php echo esc_attr( $uacf7_field_type ); ?>" class="tag code" readonly="readonly"
				onfocus="this.select()" />
			<div class="submitbox">
				<input type="button" class="button button-primary insert-tag" id="prevent_multiple"
					value="<?php echo esc_attr( __( 'Insert Tag', 'tcalls-otp-addon-for-contact-form-7' ) ); ?>" />
			</div>
		</div>
		<?php
	}

	public function uacf7_wa_otp_add_shortcodes() {
		wpcf7_add_form_tag(
			array( 'uacf7_wa_otp', 'uacf7_wa_otp*' ),
			array( $this, 'uacf7_wa_otp_tag_handler_callback' ),
			array( 'name-attr' => true )
		);
	}

	public function uacf7_wa_otp_tag_handler_callback( $tag ) {

		if ( empty( $tag->name ) ) {
			return 'Tag not Found!';
		}

		/** Enable / Disable Spam Protection */
		$wpcf7 = WPCF7_ContactForm::get_current();
		$formid = $wpcf7->id();

		$uacf7_wa_otp = uacf7_get_form_option( $formid, 'wa_otp' );

		// $uacf7_wa_otp = uacf7_get_form_option( $formid, 'spam_protection' );

		if ( isset( $uacf7_wa_otp['uacf7_wa_otp_enable'] ) && $uacf7_wa_otp['uacf7_wa_otp_enable'] != '1' ) {
			return;
		}

		$validation_error = wpcf7_get_validation_error( $tag->name );

		$class = wpcf7_form_controls_class( $tag->type );


		if ( $validation_error ) {
			$class .= 'wpcf7-not-valid';
		}

		$atts = array();


		$ip = ( isset( $_SERVER['X_FORWARDED_FOR'] ) ) ? $_SERVER['X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
		$addr = wp_remote_get( 'http://ip-api.com/php/' . $ip );
		$addr_body = wp_remote_retrieve_body( $addr );
		$addr = unserialize( $addr_body );

		$atts['iso2'] = isset( $addr['countryCode'] );
		$atts['id'] = $tag->get_id_option();

		wp_enqueue_script( 'uacf7-wa-otp-otp' );

		$atts['tabindex'] = $tag->get_option( 'tabindex', 'signed_int', true );

		if ( $tag->is_required() ) {
			$atts['aria-required'] = 'true';
		}

		$atts['aria-invalid'] = $validation_error ? 'true' : 'false';
		$atts['name'] = $tag->name;
		$atts['user-ip'] = $ip;
		$value = $tag->values;
		$default_value = $tag->get_default_option( $value );
		$atts['value'] = $value;
		$atts = wpcf7_format_atts( $atts );


		ob_start();

		?>
		<span class="wpcf7-form-control-wrap <?php echo sanitize_html_class( $tag->name ); ?>"
			data-name="<?php echo sanitize_html_class( $tag->name ); ?>">
			<div class="uacf7_otp_recognation" <?php echo esc_attr( $atts ); ?>>
				
				<div id="otp_recognation">
					<div id="otp_input_holder">
                        <!-- <label for="phone">Enter your phone number:</label>
                        <input type="text" id="phone" name="phone" placeholder="+18772345618" value=""> -->
                        <button id="otp_send" type="button">
                            Send OTP
                        </button>
                        <p id="phone-error" style="color: #DC2626;"></p>
                        <p id="sent-otp" style="color: #46b450"></p>
                        <label for="otp">Enter OTP:</label>
						<input type="number" id="otp" placeholder="<?php esc_attr_e( 'Enter OTP', 'tcalls-otp-addon-for-contact-form-7' ); ?>" min="100000" max="999999">
                        <!-- <button id="otp_check" type="button">
                            Check OTP
                        </button> -->
					</div>
					<div id="otp_result"></div>
				</div>
			
			</div>
		</span>
		<?php

		$wa_otp_buffer = ob_get_clean();

		return $wa_otp_buffer;

		// return apply_filters( 'uacf7_range_slider_style_pro_feature', $wa_otp_buffer, $tag); 

	}
}

new UACF7_SPAM_PROTECTION();
