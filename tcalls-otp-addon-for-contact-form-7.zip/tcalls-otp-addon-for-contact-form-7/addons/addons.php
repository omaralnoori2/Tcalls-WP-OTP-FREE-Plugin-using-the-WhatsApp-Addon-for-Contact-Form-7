<?php

if ( ! function_exists( 'waotpcf7_addon_included' ) ) {

	function waotpcf7_addon_included() {
		$option = uacf7_settings();


		// Addon - Wa OTP
		if ( isset( $option['uacf7_enable_wa_otp_field'] ) && $option['uacf7_enable_wa_otp_field'] == true ) {
			require_once ( 'wa-otp/ultimate-wa-otp.php' );
		}

	}
}

waotpcf7_addon_included();