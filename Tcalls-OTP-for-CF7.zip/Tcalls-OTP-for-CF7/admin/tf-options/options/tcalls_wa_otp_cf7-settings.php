<?php
// don't load directly
defined('ABSPATH') || exit;

if (file_exists(TCALLS_WA_OTP_CF7_PATH . 'admin/tf-options/options/tf-menu-icon.php')) {

	$menu_icon = TCALLS_WA_OTP_CF7_URL . 'assets/admin/images/icon.png';
} else {
	$menu_icon = 'dashicons-palmtree';
}

TCALLS_WA_OTP_CF7_Settings::option(
	'tcalls_wa_otp_cf7_settings',
	array(
		'title' => __('Tcalls OTP Addon', 'tcalls-otp-addon-for-contact-form-7'),
		'icon' => $menu_icon,
		'position' => 30.01,
		'sections' =>
			apply_filters(
				'tcalls_wa_otp_cf7_settings_options',
				array(
					'addons_settings' => array(
						'title' => __('Addons Settings', 'tcalls-otp-addon-for-contact-form-7'),
						'icon' => 'fa fa-cog',
						'fields' => array(
						),
					),
					
					'extra_fields_addons' => array(
						'title' => __('Extra Fields Addons', 'tcalls-otp-addon-for-contact-form-7'),
						'parent' => 'addons_settings',
						'icon' => 'fa fa-cog',
						'fields' => array(
							'tcalls_wa_otp_cf7_enable_wa_otp_field' => array(
								'id' => 'tcalls_wa_otp_cf7_enable_wa_otp_field',
								// 'child_field' => 'tcalls_wa_otp_cf7_enable_wa_otp_pro',
								'type' => 'switch',
								'label' => __('Whatsapp OTP', 'tcalls-otp-addon-for-contact-form-7'),
								'label_on' => __('Yes', 'tcalls-otp-addon-for-contact-form-7'),
								'label_off' => __('No', 'tcalls-otp-addon-for-contact-form-7'),
								'image_url' => TCALLS_WA_OTP_CF7_URL . 'assets/admin/images/addons/tcalls.png',
								'default' => false,
								'subtitle' => __('This feature is highly effective in ', 'tcalls-otp-addon-for-contact-form-7'),
								'demo_link' => 'https://tcalls.com/',
								'documentation_link' => 'https://tcalls.com/opt-plugin-documentation/',
								'field_width' => 33,
							),
						),
					),
				),
			)
	)
);
