<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TCALLS_WA_OTP_CF7_Admin_Menu {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'tcalls_wa_otp_cf7_add_plugin_page' ), 9999 );
	}

	/*
	 * Admin menu
	 */
	public function tcalls_wa_otp_cf7_add_plugin_page() {
		// add_submenu_page(
		// 	'tcalls_wa_otp_cf7_settings', //parent slug
		// 	__( 'Setup Wizard', 'tcalls-otp-addon-for-contact-form-7' ), // page_title
		// 	__( 'Setup Wizard', 'tcalls-otp-addon-for-contact-form-7' ), // menu_title
		// 	'manage_options', // capability 
		// 	'admin.php?page=tcalls_wa_otp_cf7-setup-wizard', // menu_slug
		// );
	}


}

new TCALLS_WA_OTP_CF7_Admin_Menu();
