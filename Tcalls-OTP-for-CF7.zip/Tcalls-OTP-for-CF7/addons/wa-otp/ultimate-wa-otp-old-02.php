<?php
if (! defined('ABSPATH')) {
    exit;
}

class TCALLS_WA_OTP_CF7_SPAM_PROTECTION
{

    public function __construct()
    {

        add_action('wpcf7_init', array($this, 'tcalls_wa_otp_cf7_wa_otp_add_shortcodes'), 5, 10);
        add_action('admin_init', array($this, 'tcalls_wa_otp_cf7_wa_otp_tag_generator'));
        add_action('wp_enqueue_scripts', array($this, 'tcalls_wa_otp_cf7_wa_otp_scripts'), 5, 10);
    }

    public function tcalls_wa_otp_cf7_wa_otp_scripts()
    {
        $option = tcalls_wa_otp_cf7_settings();
        $wa_otp_pro = (isset($option['tcalls_wa_otp_cf7_enable_wa_otp_pro']) && $option['tcalls_wa_otp_cf7_enable_wa_otp_pro'] == '1') ? true : false;
        wp_register_script('tcalls_wa_otp_cf7-wa-otp-otp', TCALLS_WA_OTP_CF7_URL . 'addons/wa-otp/assets/js/wa-otp-otp.js', ['jquery'], WPCF7_VERSION, true);
        wp_register_script('tcalls_wa_otp_cf7-wa-otp-image', TCALLS_WA_OTP_CF7_URL . 'addons/wa-otp/assets/js/wa-otp-image.js', ['jquery'], WPCF7_VERSION, true);
        wp_enqueue_style('tcalls_wa_otp_cf7-wa-otp-css', TCALLS_WA_OTP_CF7_URL . 'addons/wa-otp/assets/css/wa-otp-style.css', [], WPCF7_VERSION, 'all');

        // Localize the script to pass PHP data to JavaScript
        wp_localize_script(
            'tcalls_wa_otp_cf7-wa-otp-otp', // The handle of the script to localize
            'tcalls_wa_otp_cf7_wa_otp_settings',  // Name of the JavaScript object
            [
                'enable_wa_otp_pro' => $wa_otp_pro, // Data to pass
                'otpRequiredMessage' => __('OTP field is required. Please enter the OTP.', 'tcalls-otp-addon-for-contact-form-7'),
                'otpValidatedMessage' => __('OTP validated successfully.', 'tcalls-otp-addon-for-contact-form-7'),
                'otpValidationFailed' => __('OTP validation failed. Please try again.', 'tcalls-otp-addon-for-contact-form-7'),

                'ajax_url' => admin_url('admin-ajax.php'),
            ]
        );
    }


    public function tcalls_wa_otp_cf7_post_meta_options_wa_otp($value, $post_id)
    {
        $wa_otp = apply_filters('tcalls_wa_otp_cf7_post_meta_options_wa_otp_pro', $data = array(
            'title' => __('Wa OTP', 'tcalls-otp-addon-for-contact-form-7'),
            'icon' => 'fa-brands fa-square-whatsapp',
            'checked_field' => 'tcalls_wa_otp_cf7_wa_otp_enable',

            'fields' => []

        ), $post_id);

        $value['wa_otp'] = $wa_otp;
        return $value;
    }


    public function tcalls_wa_otp_cf7_wa_otp_tag_generator()
    {
        wpcf7_add_tag_generator(
            'tcalls_wa_otp_cf7_wa_otp',
            __('Wa OTP', 'tcalls-otp-addon-for-contact-form-7'),
            'tcalls_wa_otp_cf7-tg-pane-wa-otp',
            array($this, 'tg_pane_wa_otp')
        );
    }


    public static function tg_pane_wa_otp($contact_form, $args = '')
    {
        $args = wp_parse_args($args, array());
        $tcalls_wa_otp_cf7_field_type = 'tcalls_wa_otp_cf7_wa_otp';
?>
        <div class="control-box">
            <fieldset>
                <table class="form-table">
                    <tbody>
                        <div class="tcalls_wa_otp_cf7-doc-notice">
                            <?php echo sprintf(
                                // Translators: %1$s is replaced with the link to documentation. 
                                esc_html__('Not sure how to set this? Check our step by step  %1s.', 'tcalls-otp-addon-for-contact-form-7'),
                                '<a href="https://tcalls.com/opt-plugin-documentation/" target="_blank">documentation</a>'
                            ); ?>
                        </div>
                        <tr>
                            <th scope="row"><label
                                    for="<?php echo esc_attr($args['content'] . '-name'); ?>"><?php echo esc_html(__('Name', 'tcalls-otp-addon-for-contact-form-7')); ?></label>
                            </th>
                            <td><input type="text" name="name" class="tg-name oneline"
                                    id="<?php echo esc_attr($args['content'] . '-name'); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><label
                                    for="tag-generator-panel-text-class"><?php echo esc_html__('Class attribute', 'tcalls-otp-addon-for-contact-form-7'); ?></label>
                            </th>
                            <td><input type="text" name="class" class="classvalue oneline option"
                                    id="tag-generator-panel-text-class"></td>
                        </tr>
                    </tbody>
                </table>
            </fieldset>
        </div>
        <div class="insert-box">
            <input type="text" name="<?php echo esc_attr($tcalls_wa_otp_cf7_field_type); ?>" class="tag code" readonly="readonly"
                onfocus="this.select()" />
            <div class="submitbox">
                <input type="button" class="button button-primary insert-tag" id="prevent_multiple"
                    value="<?php echo esc_attr(__('Insert Tag', 'tcalls-otp-addon-for-contact-form-7')); ?>" />
            </div>
        </div>
    <?php
    }

    public function tcalls_wa_otp_cf7_wa_otp_add_shortcodes()
    {
        wpcf7_add_form_tag(
            array('tcalls_wa_otp_cf7_wa_otp', 'tcalls_wa_otp_cf7_wa_otp*'),
            array($this, 'tcalls_wa_otp_cf7_wa_otp_tag_handler_callback'),
            array('name-attr' => true)
        );
    }

    public function tcalls_wa_otp_cf7_wa_otp_tag_handler_callback($tag)
    {

        if (empty($tag->name)) {
            return 'Tag not Found!';
        }

        /** Enable / Disable Spam Protection */
        $wpcf7 = WPCF7_ContactForm::get_current();
        $formid = $wpcf7->id();

        $tcalls_wa_otp_cf7_wa_otp = tcalls_wa_otp_cf7_get_form_option($formid, 'wa_otp');

        if (isset($tcalls_wa_otp_cf7_wa_otp['tcalls_wa_otp_cf7_wa_otp_enable']) && $tcalls_wa_otp_cf7_wa_otp['tcalls_wa_otp_cf7_wa_otp_enable'] != '1') {
            return;
        }

        $validation_error = wpcf7_get_validation_error($tag->name);

        $class = wpcf7_form_controls_class($tag->type);


        if ($validation_error) {
            $class .= 'wpcf7-not-valid';
        }

        $atts = array();


        $ip = (isset($_SERVER['X_FORWARDED_FOR'])) ? $_SERVER['X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
        $addr = wp_remote_get('http://ip-api.com/php/' . $ip);
        $addr_body = wp_remote_retrieve_body($addr);
        $addr = unserialize($addr_body);

        $atts['iso2'] = isset($addr['countryCode']);
        $atts['id'] = $tag->get_id_option();

        wp_enqueue_script('tcalls_wa_otp_cf7-wa-otp-otp');

        $atts['tabindex'] = $tag->get_option('tabindex', 'signed_int', true);

        if ($tag->is_required()) {
            $atts['aria-required'] = 'true';
        }

        $atts['aria-invalid'] = $validation_error ? 'true' : 'false';
        $atts['name'] = $tag->name;
        $atts['user-ip'] = $ip;
        $value = $tag->values;
        $default_value = $tag->get_default_option($value);
        $atts['value'] = $value;
        $atts = wpcf7_format_atts($atts);


        ob_start();

    ?>
        <span class="wpcf7-form-control-wrap <?php echo sanitize_html_class($tag->name); ?>"
            data-name="<?php echo sanitize_html_class($tag->name); ?>">
            <div class="tcalls_wa_otp_cf7_otp_recognation" <?php echo esc_attr($atts); ?>>

                <div id="otp_recognation">
                    <div id="otp_input_holder">
                        <!-- <label for="phone">Enter your phone number:</label>
                        <input type="text" id="phone" name="phone" placeholder="+18772345618" value=""> -->
                        <button id="otp_send" type="button">
                            Send OTP
                        </button>
                        <p id="phone-error" style="color: #DC2626;"></p>
                        <p id="sent-otp" style="color: #46b450"></p>
                        <label for="otp">Enter OTP:</label>
                        <input type="number" id="otp" placeholder="<?php esc_attr_e('Enter OTP', 'tcalls-otp-addon-for-contact-form-7'); ?>" min="100000" max="999999">
                        <!-- <button id="otp_check" type="button">
                            Check OTP
                        </button> -->
                    </div>
                    <div id="otp_result"></div>
                </div>

            </div>
        </span>
<?php

        $wa_otp_buffer = ob_get_clean();

        return $wa_otp_buffer;

        // return apply_filters( 'tcalls_wa_otp_cf7_range_slider_style_pro_feature', $wa_otp_buffer, $tag); 

    }
}

new TCALLS_WA_OTP_CF7_SPAM_PROTECTION();
