window.jQuery(document).ready(function () {
  const $ = typeof window.jQuery == "undefined" ? window.$ : window.jQuery;
  var forms = $(".wpcf7-form");
  forms.each(function () {
    var formId = $(this).find('input[name="_wpcf7"]').val();
    var form_div = $(this).find(".tcalls_wa_otp_cf7-form-" + formId);
    var tcalls_wa_otp_cf7_wa_otp = $(".tcalls_wa_otp_cf7-form-" + formId).find(
      ".tcalls_wa_otp_cf7_otp_recognation"
    );

    var phone = form_div.find(".wpcf7-tel")[0];
    var phoneError = tcalls_wa_otp_cf7_wa_otp.find("#phone-error");
    var sendButton = tcalls_wa_otp_cf7_wa_otp.find("#otp_send");
    var sentOtp = tcalls_wa_otp_cf7_wa_otp.find("#sent-otp");
    var otpInput = tcalls_wa_otp_cf7_wa_otp.find("#otp");
    var resultDiv = tcalls_wa_otp_cf7_wa_otp.find("#otp_result");
    var protection_method = $(tcalls_wa_otp_cf7_wa_otp).attr(
      "protection-method"
    );

    //Send button action
    sendButton.click(function (e) {
      phoneError.text("");

      var phoneNumber = $(phone).val();
      // console.log(phoneNumber)
      const phonePattern = /^\+?[1-9]\d{10,14}$/;

      if (!phonePattern.test(phoneNumber)) {
        phoneError.text(
          "Invalid phone number. Please enter a valid international number."
        );
      } else {
        var sendData = {
          action: "send_otp_ajax_action", // The action to trigger in PHP
          nonce: tcalls_wa_otp_cf7_wa_otp_settings.nonce,
          data: { phone: phoneNumber }, // Your data to send to PHP
        };

        // console.log(tcalls_wa_otp_cf7_wa_otp_settings.ajax_url)
        $.post(
          tcalls_wa_otp_cf7_wa_otp_settings.ajax_url,
          sendData,
          function (response) {
            // console.log(response)
            if (response.success) {
              sentOtp.text(
                "Sent OTP successfully. If not received, please resend again."
              );
            } else {
              phoneError.text(response.data);
            }
          }
        );
      }

      resultDiv.text("");
      otpInput.val("");
      e.preventDefault();
    });

    //Conditionally make submission event false
    $(window).on("load", function () {
      var form_submit = tcalls_wa_otp_cf7_wa_otp
        .closest(`.tcalls_wa_otp_cf7-form-${formId}`)
        .find(".wpcf7-submit");

      form_submit.on("click", function (e) {
        e.preventDefault(); // Always prevent form submission initially

        var otpValue = otpInput.val();
        var phoneNumber = $(phone).val();

        // Check if otpValue is empty
        if (typeof otpValue !== "undefined" && otpValue.trim() === "") {
          // Field is empty, set warning message and prevent form submission
          resultDiv
            .text(tcalls_wa_otp_cf7_wa_otp_settings.otpRequiredMessage)
            .css("color", "#DC2626");
          return;
        }

        // If it's not empty, compare it with the expected value
        var compareData = {
          action: "compare_otp_ajax_action", // The action to trigger in PHP
          nonce: tcalls_wa_otp_cf7_wa_otp_settings.nonce,
          data: { phone: phoneNumber, otp: otpValue }, // Your data to send to PHP
        };

        $.post(
          tcalls_wa_otp_cf7_wa_otp_settings.ajax_url,
          compareData,
          function (response) {
            // console.log(response)
            if (response.success) {
              // OTP validated, allow form submission
              resultDiv
                .text(tcalls_wa_otp_cf7_wa_otp_settings.otpValidatedMessage)
                .css("color", "#46b450");

              // Remove preventDefault and manually submit the form
              form_submit.off("click").trigger("click");
              // form_submit.off('click');
              // tcalls_wa_otp_cf7_wa_otp.closest(`.tcalls_wa_otp_cf7-form-${formId}`).submit();
            } else {
              // If it does not match, set a failure message
              resultDiv
                .text(tcalls_wa_otp_cf7_wa_otp_settings.otpValidationFailed)
                .css("color", "#DC2626");
            }
          }
        );
      });
    });
  });
  console.log("wa-otp.js loaded");
});

// console.log("jQuery", window.jQuery);
