<?php

if (! function_exists('waotpcf7_addon_included')) {

	function waotpcf7_addon_included()
	{
		$option = tcalls_wa_otp_cf7_settings();


		// Addon - Wa OTP
		if (isset($option['tcalls_wa_otp_cf7_enable_wa_otp_field']) && $option['tcalls_wa_otp_cf7_enable_wa_otp_field'] == true) {
			require_once('wa-otp/TCALLS_WA_OTP_CF7_SPAM_PROTECTION.php');
			// require_once('wa-otp/tcalls-wa-otp-old.php');
		}
	}
}

waotpcf7_addon_included();
